import config from '../config';

module.exports = config.database;

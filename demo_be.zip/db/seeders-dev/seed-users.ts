import mongoose from 'mongoose';
import { User } from '../../src/users/user.entity';

mongoose.connect('mongodb://localhost:27017/sciflare_demo', {
  // useNewUrlParser: true,
  // useUnifiedTopology: true,
});

const seedUsers = async () => {
  const usersData = [
    {
      username: 'user1',
      email: 'user1@example.com',
      password: 'password1',
      role: 'user',
    },
    {
      username: 'user2',
      email: 'user2@example.com',
      password: 'password2',
      role: 'user',
    },
  ];

  await new User(usersData).save();

  console.log('Users seeded successfully');
  mongoose.connection.close();
};

seedUsers();

export const config = {
  database: {
    mongoUri: 'mongodb://localhost:27017/sciflare_demo',
  },
  jwtPrivateKey: process.env.JWT_PRIVATE_KEY,
};

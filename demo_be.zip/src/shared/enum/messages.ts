/* eslint-disable prettier/prettier */
export enum Message {
  CREATED = 'Record created Successfully',
  FETCHED = 'Record fetched Successfully',
}

export interface JwtPayload {
  email: string;
  iat?: Date;
}
